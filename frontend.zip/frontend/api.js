import axios from 'axios';

const API = axios.create({
  baseURL: 'http://localhost:5000/api', // backend URL
});

// APIs
export const getInventory = () => API.get('/inventory');
export const getLogs = (params) => API.get('/logs', { params });
export const updateNotification = (userId, enabled) =>
  API.post(`/users/${userId}/notifications`, { enabled });

export default API;
