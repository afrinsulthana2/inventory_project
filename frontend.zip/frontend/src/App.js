import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './App.css';

function App() {
  const [products, setProducts] = useState([]);
  const [logs, setLogs] = useState([]);
  const [filters, setFilters] = useState({ action: '', userId: '', date: '' });
  const [inputs, setInputs] = useState({});
  const [users, setUsers] = useState([]);
  const [selectedUser, setSelectedUser] = useState('');

  useEffect(() => {
    fetchProducts();
    fetchLogs();
    fetchUsers();
  }, []);

  const fetchProducts = async () => {
    const res = await axios.get('http://localhost:5000/api/inventory');
    setProducts(res.data);
  };

  const fetchLogs = async () => {
    const res = await axios.get('http://localhost:5000/api/logs');
    setLogs(res.data);
  };

  const fetchUsers = async () => {
    const res = await axios.get('http://localhost:5000/api/alerts/users');
    setUsers(res.data);
  };

  const handleUpdate = async (productId) => {
    const input = inputs[productId];
    if (!input || !input.quantity || !input.action || !selectedUser) {
      alert('Please select user, enter quantity, and select action');
      return;
    }

    try {
      await axios.post('http://localhost:5000/api/inventory/update-stock', {
        product_id: productId,
        quantity: parseInt(input.quantity),
        action: input.action,
        user_id: selectedUser,
      });
      fetchProducts();
      fetchLogs();
      setInputs({ ...inputs, [productId]: { quantity: '', action: '' } });
    } catch (err) {
      console.error(err);
      alert('Stock update failed');
    }
  };

  const applyFilters = async () => {
    const res = await axios.get('http://localhost:5000/api/logs', {
      params: filters,
    });
    setLogs(res.data);
  };

  return (
    <div style={{ padding: '30px' }}>
      <h1>Inventory Dashboard</h1>

      <div>
        <label>Select User:</label>
        <select value={selectedUser} onChange={(e) => setSelectedUser(e.target.value)}>
          <option value="">Choose User</option>
          {users.map((u) => (
            <option key={u.id} value={u.id}>{u.name}</option>
          ))}
        </select>
      </div>

      <h2>Current Inventory</h2>
      <table border="1" cellPadding="10">
        <thead>
          <tr>
            <th>Name</th>
            <th>Stock</th>
            <th>Threshold</th>
            <th>Quantity</th>
            <th>Action</th>
            <th>Submit</th>
          </tr>
        </thead>
        <tbody>
          {products.map((p) => (
            <tr
              key={p.id}
              style={{
                backgroundColor: p.stock < p.threshold ? '#ffcccc' : 'transparent',
              }}
            >
              <td>{p.name}</td>
              <td>{p.stock ?? '-'}</td>
              <td>{p.threshold ?? '-'}</td>
              <td>
                <input
                  type="number"
                  value={inputs[p.id]?.quantity || ''}
                  onChange={(e) =>
                    setInputs({
                      ...inputs,
                      [p.id]: {
                        ...inputs[p.id],
                        quantity: e.target.value,
                      },
                    })
                  }
                />
              </td>
              <td>
                <select
                  value={inputs[p.id]?.action || ''}
                  onChange={(e) =>
                    setInputs({
                      ...inputs,
                      [p.id]: {
                        ...inputs[p.id],
                        action: e.target.value,
                      },
                    })
                  }
                >
                  <option value="">Select</option>
                  <option value="sale">Sale</option>
                  <option value="return">Return</option>
                  <option value="restock">Restock</option>
                </select>
              </td>
              <td>
                <button onClick={() => handleUpdate(p.id)}>Submit</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <h2>Inventory Logs</h2>
      <div>
        <label>Action:</label>
        <select
          value={filters.action}
          onChange={(e) => setFilters({ ...filters, action: e.target.value })}
        >
          <option value="">All</option>
          <option value="sale">Sale</option>
          <option value="return">Return</option>
          <option value="restock">Restock</option>
        </select>
        <label>User ID:</label>
        <input
          type="number"
          value={filters.userId}
          onChange={(e) => setFilters({ ...filters, userId: e.target.value })}
        />
        <label>Date:</label>
        <input
          type="date"
          value={filters.date}
          onChange={(e) => setFilters({ ...filters, date: e.target.value })}
        />
        <button onClick={applyFilters}>Apply Filters</button>
      </div>

      <table border="1" cellPadding="10">
        <thead>
          <tr>
            <th>ID</th>
            <th>Product Name</th>
            <th>Action</th>
            <th>Quantity</th>
            <th>User ID</th>
            <th>Timestamp</th>
          </tr>
        </thead>
        <tbody>
          {logs.map((log) => (
            <tr key={log.id}>
              <td>{log.id}</td>
              <td>{log.product_name}</td>
              <td>{log.action}</td>
              <td>{log.quantity}</td>
              <td>{log.user_id}</td>
              <td>{new Date(log.timestamp).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })}</td>

            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default App;
