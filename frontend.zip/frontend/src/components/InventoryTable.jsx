import React, { useEffect, useState } from 'react';
import axios from 'axios';

function InventoryTable() {
  const [products, setProducts] = useState([]);
  const [quantities, setQuantities] = useState({});

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    const res = await axios.get('http://localhost:5000/api/inventory');
    setProducts(res.data);
  };

  const handleUpdate = async (id, action) => {
    const qty = parseInt(quantities[id]) || 0;
    await axios.post('http://localhost:5000/api/inventory/update-stock', {
      product_id: id,
      quantity: qty,
      action,
      user_id: 1,
    });
    fetchProducts();
    setQuantities({ ...quantities, [id]: '' });
  };

  return (
    <div>
      <h2>Inventory</h2>
      <table border="1" cellPadding="8">
        <thead>
          <tr>
            <th>Name</th>
            <th>Stock</th>
            <th>Threshold</th>
            <th>Qty</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {products.map(prod => (
            <tr key={prod.id} style={{ backgroundColor: prod.stock < prod.threshold ? '#ffe6e6' : 'white' }}>
              <td>{prod.name}</td>
              <td>{prod.stock}</td>
              <td>{prod.threshold}</td>
              <td>
                <input
                  type="number"
                  value={quantities[prod.id] || ''}
                  onChange={(e) => setQuantities({ ...quantities, [prod.id]: e.target.value })}
                />
              </td>
              <td>
                <button onClick={() => handleUpdate(prod.id, 'sale')}>Sale</button>
                <button onClick={() => handleUpdate(prod.id, 'return')}>Return</button>
                <button onClick={() => handleUpdate(prod.id, 'restock')}>Restock</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default InventoryTable;
