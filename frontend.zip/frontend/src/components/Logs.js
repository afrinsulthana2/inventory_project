import React, { useEffect, useState } from 'react';
import axios from 'axios';

function Logs() {
  const [logs, setLogs] = useState([]);
  const [filters, setFilters] = useState({ action: '', userId: '', date: '' });

  useEffect(() => {
    fetchLogs();
  }, []);

  const fetchLogs = async () => {
    const res = await axios.get('http://localhost:5000/api/logs', { params: filters });
    setLogs(res.data);
  };

  return (
    <div>
      <h2>Inventory Logs</h2>
      <div>
        <input placeholder="Action" onChange={(e) => setFilters({ ...filters, action: e.target.value })} />
        <input placeholder="User ID" onChange={(e) => setFilters({ ...filters, userId: e.target.value })} />
        <input type="date" onChange={(e) => setFilters({ ...filters, date: e.target.value })} />
        <button onClick={fetchLogs}>Filter</button>
      </div>
      <table border="1" cellPadding="8">
        <thead>
          <tr>
            <th>Product</th>
            <th>Action</th>
            <th>Qty</th>
            <th>User</th>
            <th>Time</th>
          </tr>
        </thead>
        <tbody>
          {logs.map((log, index) => (
            <tr key={index}>
              <td>{log.product_name}</td>
              <td>{log.action}</td>
              <td>{log.quantity}</td>
              <td>{log.user_id}</td>
              <td>{new Date(log.created_at).toLocaleString()}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default Logs;
