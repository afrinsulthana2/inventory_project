import React from 'react';
import InventoryTable from './components/InventoryTable';

function App() {
  return (
    <div style={{ padding: '30px', fontFamily: 'sans-serif' }}>
      <h1>Inventory Dashboard</h1>
      <InventoryTable />
    </div>
  );
}

export default App;
