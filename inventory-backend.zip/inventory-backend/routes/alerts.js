// routes/alerts.js
const express = require('express');
const router = express.Router();
const pool = require('../db');

// Fetch all users for frontend dropdown
router.get('/users', async (req, res) => {
  try {
    const result = await pool.query('SELECT id, name FROM users');
    res.json(result.rows);
  } catch (err) {
    console.error('Error fetching users:', err.message);
    res.status(500).send('Error fetching users');
  }
});

// Not needed unless you want to manually toggle alert_enabled via API
router.post('/set-preference', async (req, res) => {
  const { user_id, preference } = req.body;
  await pool.query(`UPDATE users SET alert_enabled = $1 WHERE id = $2`, [preference, user_id]);
  res.send('Preference updated');
});

module.exports = router;
