const express = require('express');
const router = express.Router();
const pool = require('../db');
const nodemailer = require('nodemailer');
require('dotenv').config();

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: process.env.SMTP_PORT,
  secure: false,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

router.get('/', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM products ORDER BY id');
    res.json(result.rows);
  } catch (err) {
    console.error('Error fetching products:', err.message);
    res.status(500).send('Error fetching products');
  }
});

router.post('/update-stock', async (req, res) => {
  const { product_id, quantity, action, user_id } = req.body;

  if (!product_id || !quantity || !action || !user_id) {
    return res.status(400).json({ error: 'Missing fields' });
  }

  try {
    let newStockQuery;

    if (action === 'sale') {
      newStockQuery = `UPDATE products SET stock = stock - $1 WHERE id = $2 RETURNING *`;
    } else if (action === 'return' || action === 'restock') {
      newStockQuery = `UPDATE products SET stock = stock + $1 WHERE id = $2 RETURNING *`;
    } else {
      return res.status(400).send('Invalid action');
    }

    const updated = await pool.query(newStockQuery, [quantity, product_id]);

    if (updated.rows.length === 0) {
      return res.status(404).send('Product not found');
    }

    const updatedProduct = updated.rows[0];

    await pool.query(
      'INSERT INTO inventory_logs (inventory_id, action, quantity, user_id) VALUES ($1, $2, $3, $4)',
      [product_id, action, quantity, user_id]
    );

    if (updatedProduct.stock < updatedProduct.threshold) {
      const emailRes = await pool.query(
        'SELECT email FROM users WHERE id = $1 AND alert_enabled = true',
        [user_id]
      );

      const recipient = emailRes.rows[0]?.email;

      if (recipient) {
        const mailOptions = {
          from: process.env.SMTP_USER,
          to: recipient,
          subject: `Alert: Low Stock for ${updatedProduct.name}`,
          text: `Only ${updatedProduct.stock} left in stock.`,
        };

        await transporter.sendMail(mailOptions);
        console.log('📧 Alert email sent to', recipient);
      } else {
        console.log('No alert recipient found.');
      }
    }

    res.json({ message: '✅ Stock updated & log saved', product: updatedProduct });
  } catch (err) {
    console.error('Error updating stock:', err.message);
    res.status(500).send('Internal Server Error');
  }
});

module.exports = router;
