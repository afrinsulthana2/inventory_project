const express = require('express');
const router = express.Router();
const pool = require('../db');

router.get('/', async (req, res) => {
  const { action, userId, date } = req.query;

  let base = `
    SELECT il.*, p.name as product_name 
    FROM inventory_logs il
    JOIN products p ON il.inventory_id = p.id 
    WHERE 1=1
  `;
  const values = [];
  let count = 1;

  if (action) {
    base += ` AND il.action = $${count++}`;
    values.push(action);
  }

  if (userId) {
    base += ` AND il.user_id = $${count++}`;
    values.push(userId);
  }

  if (date) {
    base += ` AND DATE(il.timestamp) = $${count++}`; // 🔄 Changed from created_at to timestamp
    values.push(date);
  }

  base += ' ORDER BY il.timestamp DESC'; // 🔄 Changed from created_at to timestamp

  try {
    const result = await pool.query(base, values);
    res.json(result.rows);
  } catch (err) {
    console.error('Error fetching logs:', err.message);
    res.status(500).send('Error fetching logs');
  }
});

module.exports = router;
