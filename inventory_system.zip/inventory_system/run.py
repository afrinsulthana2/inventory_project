from inventory import create_app, db
from inventory.models import Product

app = create_app()


with app.app_context():
    db.create_all()

    from inventory.models import Product

    # Only add if empty
    if not Product.query.first():
        sample = Product(
            id="1",
            sku="P001",
            name="Test Product",
            barcode="123456789",
            category="Sample Category",
            stock=10,
            threshold=5,
            expiry_date="2025-12-31"
        )
        db.session.add(sample)
        db.session.commit()


if __name__ == '__main__':
    app.run(debug=True)
