from flask_wtf import FlaskForm
from wtforms import StringField, IntegerField, SubmitField
from wtforms.validators import DataRequired
from wtforms.fields import DateField

class ProductForm(FlaskForm):
    sku = StringField('SKU', validators=[DataRequired()])
    name = StringField('Name', validators=[DataRequired()])
    barcode = StringField('Barcode', validators=[DataRequired()])
    category = StringField('Category', validators=[DataRequired()])
    stock = IntegerField('Stock', validators=[DataRequired()])
    threshold = IntegerField('Threshold', validators=[DataRequired()])
    expiry_date = DateField('Expiry Date', format='%Y-%m-%d')  # Can add validation if needed
    submit = SubmitField('Add Product')