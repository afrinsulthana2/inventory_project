from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required
from ..models import Product, db
from ..auth.decorators import admin_required, staff_required
from .forms import ProductForm
from datetime import datetime

product = Blueprint('product', __name__)

# ✅ All users can view products
@product.route('/')
@login_required
def view_products():
    products = Product.query.all()
    return render_template('product/product_list.html', products=products)

# ✅ Only Admins can create products
@product.route('/create', methods=['GET', 'POST'])
@login_required
@admin_required
def create_product():
    form = ProductForm()
    if form.validate_on_submit():
        try:
            new_product = Product(
                sku=form.sku.data,
                name=form.name.data,
                barcode=form.barcode.data,
                category=form.category.data,
                stock=form.stock.data,
                threshold=form.threshold.data,
                expiry_date=form.expiry_date.data
            )
            db.session.add(new_product)
            db.session.commit()
            print("✅ Product created:", new_product.sku, new_product.name, new_product.stock)
            flash('Product created successfully!', 'success')
            return redirect(url_for('product.view_products'))
        except Exception as e:
            db.session.rollback()
            print("❌ DB Error:", e)
            flash('Database error occurred.', 'danger')
    elif request.method == 'POST':
        print("❌ Form validation failed.")
        print(form.errors)
    return render_template('product/add_product.html', form=form)

# ✅ Only Admins can edit products
@product.route('/edit/<int:product_id>', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_product(product_id):
    product_obj = Product.query.get_or_404(product_id)

    # Optional: Ensure expiry_date is a valid date
    if isinstance(product_obj.expiry_date, str):
        try:
            product_obj.expiry_date = datetime.strptime(product_obj.expiry_date, '%Y-%m-%d').date()
        except ValueError:
            product_obj.expiry_date = None

    form = ProductForm(obj=product_obj)

    if form.validate_on_submit():
        form.populate_obj(product_obj)
        db.session.commit()
        flash('Product updated successfully!', 'success')
        return redirect(url_for('product.view_products'))

    return render_template('product/edit_product.html', form=form, product=product_obj)

# ✅ Only Admins can delete products
@product.route('/delete/<int:product_id>', methods=['POST'])
@login_required
@admin_required
def delete_product(product_id):
    product_obj = Product.query.get_or_404(product_id)
    db.session.delete(product_obj)
    db.session.commit()
    flash('Product deleted successfully!', 'success')
    return redirect(url_for('product.view_products'))

@product.route('/staff-only')
@login_required
@staff_required
def staff_dashboard():
    return render_template('staff_dashboard.html')