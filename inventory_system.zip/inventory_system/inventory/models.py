from inventory import db, login_manager
from flask_login import UserMixin
from inventory import bcrypt
from datetime import date
from sqlalchemy import Date
from sqlalchemy.orm import validates


class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), nullable=False)  # ✅ required
    email = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(256), nullable=False)
    role = db.Column(db.String(10), nullable=False, default='Staff')  # Admin or Staff
    @validates('role')
    def convert_role(self, key, value):
        return value.strip().capitalize()

    def check_password(self, password):
        return bcrypt.check_password_hash(self.password, password)
    
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    sku = db.Column(db.String(100), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    barcode = db.Column(db.String(100), nullable=False)
    category = db.Column(db.String(100), nullable=False)
    stock = db.Column(db.Integer, nullable=False)
    threshold = db.Column(db.Integer, nullable=False)
    expiry_date = db.Column(Date, nullable=True)
    def is_low_stock(self):
        return self.stock <= self.threshold
    
    def __repr__(self):
        return f'<Product {self.name}>'