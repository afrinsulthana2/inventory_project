from flask import redirect, url_for, flash
from functools import wraps
from flask_login import current_user

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        print("🔍 User Authenticated:", current_user.is_authenticated)
        print("🔍 User Role:", getattr(current_user, 'role', None))  # Safe check

        if not current_user.is_authenticated:
            flash("Please log in first.", "warning")
            return redirect(url_for('auth.login'))
        if current_user.role != 'admin':
            flash("You are not authorized to access this page.", "danger")
            return redirect(url_for('product.view_products'))
        return f(*args, **kwargs)
    return decorated_function

def staff_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            flash("Please log in first.", "warning")
            return redirect(url_for('auth.login'))
        if current_user.role != 'staff':
            flash("Only staff members can access this page.", "danger")
            return redirect(url_for('product.view_products'))
        return f(*args, **kwargs)
    return decorated_function