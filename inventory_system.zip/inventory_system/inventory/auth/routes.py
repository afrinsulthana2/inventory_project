from flask import Blueprint, render_template, redirect, url_for, request, flash
from flask_login import login_required, login_user, logout_user, current_user
from ..models import User, Product
from .. import db, bcrypt
from .forms import RegisterForm, LoginForm
from werkzeug.security import generate_password_hash

auth = Blueprint('auth', __name__)

@auth.route('/register', methods=['GET', 'POST'])
def register():
    form = RegisterForm()
    if form.validate_on_submit():
        hashed_pw = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
        new_user = User(
            username=form.username.data,
            email=form.email.data,
            password=hashed_pw,
            role=form.role.data.strip().capitalize() 
        )
        db.session.add(new_user)
        db.session.commit()
        flash('Account created!', 'success')
        return redirect(url_for('auth.login'))
    return render_template('auth/register.html', form=form)

@auth.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        email = form.email.data
        password = form.password.data
        user = User.query.filter_by(email=email).first()

        if user and user.check_password(password):
            login_user(user)
            flash('Login successful!')
            return redirect(url_for('auth.dashboard'))
        else:
            flash('Invalid email or password.')

    return render_template('auth/login.html', form=form)


@auth.route('/')
def home():
    return redirect(url_for('auth.login'))


@auth.route('/dashboard')
@login_required
def dashboard():
    print("Current User Role:", current_user.role)
    products = Product.query.all()
    low_stock = [p for p in products if p.stock <= p.threshold]
    return render_template('auth/dashboard.html', name=current_user.username, products=products, low_stock=low_stock)


@auth.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.')
    return redirect(url_for('auth.login'))
